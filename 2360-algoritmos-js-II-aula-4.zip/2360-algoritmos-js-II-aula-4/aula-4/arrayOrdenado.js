const listaLivros = [
  {
    titulo: 'PHP',
    preco: 15
  },
  {
    titulo: 'Python',
    preco: 20
  },
  {
    titulo: 'Rust',
    preco: 22
  },
  {
    titulo: 'JavaScript',
    preco: 25
  },
  {
    titulo: 'Ruby',
    preco: 28
  },
  {
    titulo: 'Java',
    preco: 30
  },
  {
    titulo: 'C#',
    preco: 33
  },
  {
    titulo: 'C++',
    preco: 35
  },
  {
    titulo: 'Scala',
    preco: 40
  },
  {
    titulo: 'Go',
    preco: 45
  },
  {
    titulo: 'Elixir',
    preco: 50
  }
]


module.exports = listaLivros